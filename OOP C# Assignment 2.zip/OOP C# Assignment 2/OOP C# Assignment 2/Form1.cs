﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP_C__Assignment_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double s1, s2, s3, s4, s5, s6;

            double m1 = double.Parse(textBox1.Text);
            double m2 = double.Parse(textBox2.Text);
            double m3 = double.Parse(textBox3.Text);
            double m4 = double.Parse(textBox4.Text);
            double m5 = double.Parse(textBox5.Text);
            double m6 = double.Parse(textBox6.Text);



            if (textBox1.Text == "")
            {
                MessageBox.Show("Please Fill All Boxs!");
            }
            else if (m1 < 0 || m1 > 100)
            {
                MessageBox.Show("Marks Should be Between 0 and 100");
            }
            else if (checkBox1.Checked  )
            {
                m1 = 0;
                comboBox1.SelectedIndex = 0;
            }
            else
            {
                if (m1 <= 100 && m1 >= 90)
                {
                        m1 = 4.0;
                }
                else if (m1 <= 89 && m1 >= 80)
                {
                    m1 = 4.0;
                }
                else if ( m1 <= 79 && m1 >= 70)
                {
                    m1 = 3.0;
                }
                else if (   m1 <= 69 && m1 >= 60)
                {
                    m1 = 2.0;
                }
                else if ( m1 <= 59 && m1 >= 50)
                {
                    m1 = 1.0;
                }
                else
                {
                    m1 = 0.0;
                }

               //s1 = comboBox1.SelectedIndex * m1;

            }
           

            if (textBox2.Text == "")
            {
                MessageBox.Show("Please Fill All Boxs!");
            }
            else if (m2 < 0 || m2 > 100)
            {
                MessageBox.Show("Marks Should be Between 0 and 100");
            }
            else  if (checkBox2.Checked)
            {
                m2 = 0;
                comboBox2.SelectedIndex = 0;
            }
            else
            {
                if (m2 <= 100 && m2 >= 90)
                {
                    m2 = 4.0;
                }
                else if (m2 <= 89 && m2 >= 80)
                {
                    m2 = 4.0;
                }
                else if (   m2 <= 79 && m2 >= 70)
                {
                    m2 = 3.0;
                }
                else if (   m2 <= 69 && m2 >= 60)
                {
                    m2 = 2.0;
                }
                else if (m2 <= 59 && m2 >= 50)
                {
                    m2 = 1.0;
                }
                else
                {
                    m2 = 0.0;
                }
              // s2 = comboBox2.SelectedIndex * m2;
            }
            

            if (textBox3.Text == "")
            {
                MessageBox.Show("Please Fill All Boxs!");
            }
            else if (m3 < 0 || m3 > 100)
            {
                MessageBox.Show("Marks Should be Between 0 and 100");
            }
           else   if (checkBox3.Checked)
            {
                m3 = 0;
                comboBox3.SelectedIndex = 0;
            }
            else
            {
                if (m3 <= 100 && m3 >= 90)
                {
                    m3 = 4.0;
                }
                else if (m3 <= 89 && m3 >= 80)
                {
                    m3 = 4.0;
                }
                else if (m3 <= 79 && m3 >= 70)
                {
                    m3 = 3.0;
                }
                else if (m3 <= 69 && m3 >= 60)
                {
                    m3 = 2.0;
                }
                else if (m3 <= 59 && m3 >= 50)
                {
                    m3 = 1.0;
                }
                else
                {
                    m3 = 0.0;
                }
               //s3 = comboBox3.SelectedIndex * m3;
            }
            


            if (textBox4.Text == "")
            {
                MessageBox.Show("Please Fill All Boxs!");
            }
            else if (m4 < 0 || m4 > 100)
            {
                MessageBox.Show("Marks Should be Between 0 and 100");
            }
            else if (checkBox4.Checked)
            {
                m4 = 0;
                comboBox4.SelectedIndex = 0;
            }
            else
            {
                if (m4 <= 100 && m4 >= 90)
                {
                    m4 = 4.0;
                }
                else if (m4 <= 89 && m4 >= 80)
                {
                    m4 = 4.0;
                }
                else if (m4 <= 79 && m4 >= 70)
                {
                    m4 = 3.0;
                }
                else if (m4 <= 69 && 4 >= 60)
                {
                    m4 = 2.0;
                }
                else if (m4 <= 59 && m4 >= 50)
                {
                    m4 = 1.0;
                }
                else
                {
                    m4 = 0.0;
                }
               // s4 = comboBox4.SelectedIndex * m4;
            }
            


            if (textBox5.Text == "")
            {
                MessageBox.Show("Please Fill All Boxs!");
            }
            else if (m5 < 0 || m5 > 100)
            {
                MessageBox.Show("Marks Should be Between 0 and 100");
            }
            else if (checkBox5.Checked)
            {
                m5 = 0;
                comboBox5.SelectedIndex = 0;
            }
            else
            {
                if (m5 <= 100 && m5 >= 90)
                {
                    m5 = 4.0;
                }
                else if (m5 <= 89 && m5 >= 80)
                {
                    m5 = 4.0;
                }
                else if (m5 <= 79 &&  m5 >= 70)
                {
                    m5 = 3.0;
                }
                else if (m5 <= 69 && m5 >= 60)
                {
                    m5 = 2.0;
                }
                else if (m5 <= 59 && m5 >= 50)
                {
                    m5 = 1.0;
                }
                else
                {
                    m5 = 0.0;
                }
               // s5 = comboBox5.SelectedIndex * m5;
            }
           

            if (textBox6.Text == "")
            {
                MessageBox.Show("Please Fill All Boxs!");
            }
            else if (m6 < 0 || m6 > 100)
            {
                MessageBox.Show("Marks Should be Between 0 and 100");
            }
            else if (checkBox6.Checked)
            {
                 m6 = 0;
                comboBox6.SelectedIndex = 0;
            }
            else
            {
                if (m6 <= 100 && m6 >= 90)
                {
                    m6 = 4.0;
                }
                else if (m6 <= 89 && m6 >= 80)
                {
                    m6 = 4.0;
                }
                else if (m6 <= 79 && m6 >= 70)
                {
                    m6 = 3.0;
                }
                else if (m6 <= 69 && m6 >= 60)
                {
                    m6 = 2.0;
                }
                else if (m6 <= 59 && m6 >= 50)
                {
                    m6 = 1.0;
                }
                else
                {
                    m6 = 0.0;
                }
                //s6 = comboBox6.SelectedIndex * m6;
            }

            s1 = comboBox1.SelectedIndex * m1;
            s2 = comboBox2.SelectedIndex * m2;
            s3 = comboBox3.SelectedIndex * m3;
            s4 = comboBox4.SelectedIndex * m4;
            s5 = comboBox5.SelectedIndex * m5;
            s6 = comboBox6.SelectedIndex * m6;

            float total_cerdit_hrs = comboBox1.SelectedIndex + comboBox2.SelectedIndex + comboBox3.SelectedIndex + comboBox4.SelectedIndex + comboBox5.SelectedIndex + comboBox6.SelectedIndex;

            double gpa =(double) (( s1 + s2 + s3 + s4 + s5 + s6) / total_cerdit_hrs);
            label11.Text = "GPA = " + gpa.ToString("0.00");
            label11.Visible = true;

        }

        
    }
}
